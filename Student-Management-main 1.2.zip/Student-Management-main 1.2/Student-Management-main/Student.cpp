#include "student.h"
#include <iostream>
#include <iomanip>
#include <sstream>

Student::Student(std::string n, int bYear, std::string m, std::string i, float g)
    : name(n), birthYear(bYear), major(m), id(i), gpa(g) {}

std::string Student::getId() const { return id; }
std::string Student::getName() const { return name; }
int Student::getBirthYear() const { return birthYear; }
std::string Student::getMajor() const { return major; }
float Student::getGpa() const { return gpa; }

void Student::setName(const std::string& n) { name = n; }
void Student::setBirthYear(int bYear) { birthYear = bYear; }
void Student::setMajor(const std::string& m) { major = m; }
void Student::setGpa(float g) { gpa = g; }

void Student::display() const {
    std::cout << "ID: " << id 
              << " | Name: " << name 
              << " | Birth Year: " << birthYear 
              << " | Major: " << major 
              << " | GPA: " << std::fixed << std::setprecision(2) << gpa << "\n";
}

// Formats data as comma-separated values for easy file saving
std::string Student::toFileString() const {
    std::stringstream ss;
    ss << name << "," << birthYear << "," << major << "," << id << "," << std::fixed << std::setprecision(2) << gpa;
    return ss.str();
}