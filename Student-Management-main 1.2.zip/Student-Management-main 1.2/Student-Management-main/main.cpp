#include "management.h"

int main() {
    Management sys;
    sys.run();
    return 0;
}