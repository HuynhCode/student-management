#include "management.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cctype>
#include <algorithm>

const int CURRENT_YEAR = 2026;

Management::Management() {
    loadFromFile(); // Automatically load existing records when system starts
}

Management::~Management() {
    saveToFile(); // Automatically save records when system closes
}

// --- Validation Logic ---
bool Management::isValidName(const std::string& name) {
    if (name.empty()) return false;
    for (char c : name) {
        if (!std::isalpha(c) && !std::isspace(c)) return false;
    }
    return true;
}

bool Management::isValidBirthYear(int year) {
    return (year > 1950 && year < (CURRENT_YEAR - 18));
}

bool Management::isValidId(const std::string& id) {
    if (id.empty()) return false;
    return id.find('-') == std::string::npos; // Cannot contain '-'
}

bool Management::isValidGPA(const std::string& gpaStr, float& gpaOut) {
    try {
        size_t pos;
        float gpa = std::stof(gpaStr, &pos);
        if (pos != gpaStr.length()) return false; 
        if (gpa < 0.0f || gpa > 4.0f) return false;
        
        size_t dotPos = gpaStr.find('.');
        if (dotPos != std::string::npos && (gpaStr.length() - dotPos - 1 > 2)) {
            return false; 
        }
        gpaOut = gpa;
        return true;
    } catch (...) {
        return false;
    }
}

// --- Input Helpers ---
std::string Management::inputName() {
    std::string name;
    while (true) {
        std::cout << "Enter name (letters only): ";
        std::getline(std::cin, name);
        if (isValidName(name)) return name;
        std::cout << "Invalid input! Name must only contain letters.\n";
    }
}

int Management::inputBirthYear() {
    std::string yearStr;
    while (true) {
        std::cout << "Enter birth year (> 1950 and < " << (CURRENT_YEAR - 18) << "): ";
        std::getline(std::cin, yearStr);
        try {
            int year = std::stoi(yearStr);
            if (isValidBirthYear(year)) return year;
        } catch (...) {}
        std::cout << "Invalid input! Please enter a valid qualifying year.\n";
    }
}

std::string Management::inputMajor() {
    std::string major;
    std::cout << "Enter major: ";
    std::getline(std::cin, major);
    return major;
}

std::string Management::inputId() {
    std::string id;
    while (true) {
        std::cout << "Enter ID roll number (cannot contain '-'): ";
        std::getline(std::cin, id);
        if (isValidId(id)) return id;
        std::cout << "Invalid input! ID cannot contain the '-' symbol.\n";
    }
}

float Management::inputGPA() {
    std::string gpaStr;
    float gpa;
    while (true) {
        std::cout << "Enter GPA (0.0 to 4.0, max 2 decimal places): ";
        std::getline(std::cin, gpaStr);
        if (isValidGPA(gpaStr, gpa)) return gpa;
        std::cout << "Invalid input! Ensure GPA is between 0.0 and 4.0 with proper precision.\n";
    }
}

// --- Core Features ---
void Management::addStudent() {
    std::cout << "\n--- Add New Student ---\n";
    std::string name = inputName();
    int birthYear = inputBirthYear();
    std::string major = inputMajor();
    std::string id = inputId();
    float gpa = inputGPA();

    // Check if ID already exists
    for (const auto& s : students) {
        if (s.getId() == id) {
            std::cout << "Error: A student with ID " << id << " already exists!\n";
            return;
        }
    }

    students.emplace_back(name, birthYear, major, id, gpa);
    std::cout << "Student added successfully!\n";
}

void Management::editStudent() {
    std::cout << "\n--- Edit Student ---\n";
    std::string searchId;
    std::cout << "Enter the ID of the student to edit: ";
    std::getline(std::cin, searchId);

    for (auto& student : students) {
        if (student.getId() == searchId) {
            std::cout << "Student found! Enter new details:\n";
            student.setName(inputName());
            student.setBirthYear(inputBirthYear());
            student.setMajor(inputMajor());
            student.setGpa(inputGPA());
            std::cout << "Student records updated successfully!\n";
            return;
        }
    }
    std::cout << "Student with ID " << searchId << " not found.\n";
}

void Management::deleteStudent() {
    std::cout << "\n--- Delete Student ---\n";
    std::string searchId;
    std::cout << "Enter the ID of the student to delete: ";
    std::getline(std::cin, searchId);

    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->getId() == searchId) {
            students.erase(it);
            std::cout << "Student deleted successfully!\n";
            return;
        }
    }
    std::cout << "Student with ID " << searchId << " not found.\n";
}

void Management::displayStudent() const {
    if (students.empty()) {
        std::cout << "\nNo students to display.\n";
        return;
    }
    std::cout << "\n--- Student List ---\n";
    for (const auto& student : students) {
        student.display();
    }
    std::cout << "--------------------\n";
}

void Management::saveToFile() const {
    std::ofstream outFile(filename);
    if (!outFile) {
        std::cout << "Error: Could not open file to save data.\n";
        return;
    }
    for (const auto& student : students) {
        outFile << student.toFileString() << "\n";
    }
    outFile.close();
    std::cout << "Data successfully saved to " << filename << ".\n";
}

void Management::loadFromFile() {
    std::ifstream inFile(filename);
    if (!inFile) {
        // Normal behavior on first run if file doesn't exist yet
        return; 
    }

    students.clear();
    std::string line;
    while (std::getline(inFile, line)) {
        std::stringstream ss(line);
        std::string name, yearStr, major, id, gpaStr;

        std::getline(ss, name, ',');
        std::getline(ss, yearStr, ',');
        std::getline(ss, major, ',');
        std::getline(ss, id, ',');
        std::getline(ss, gpaStr, ',');

        if (!name.empty() && !yearStr.empty() && !id.empty() && !gpaStr.empty()) {
            try {
                int year = std::stoi(yearStr);
                float gpa = std::stof(gpaStr);
                students.emplace_back(name, year, major, id, gpa);
            } catch (...) {
                std::cout << "Warning: Corrupt data skipped in file.\n";
            }
        }
    }
    inFile.close();
}

void Management::run() {
    std::string choiceStr;
    while (true) {
        std::cout << "\n--- Main Menu ---\n";
        std::cout << "1. Add Student\n";
        std::cout << "2. Edit Student\n";
        std::cout << "3. Delete Student\n";
        std::cout << "4. Display All Students\n";
        std::cout << "5. Save Data to File\n";
        std::cout << "6. Load Data from File\n";
        std::cout << "7. Exit\n";
        std::cout << "Choose an option: ";
        std::getline(std::cin, choiceStr);

        if (choiceStr == "1") {
            addStudent();
        } else if (choiceStr == "2") {
            editStudent();
        } else if (choiceStr == "3") {
            deleteStudent();
        } else if (choiceStr == "4") {
            displayStudent();
        } else if (choiceStr == "5") {
            saveToFile();
        } else if (choiceStr == "6") {
            loadFromFile();
            std::cout << "Data loaded from file.\n";
        } else if (choiceStr == "7") {
            std::cout << "Exiting system and saving data...\n";
            break;
        } else {
            std::cout << "Invalid choice. Please enter a number from 1 to 7.\n";
        }
    }
}