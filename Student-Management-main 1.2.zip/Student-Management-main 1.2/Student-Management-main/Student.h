#ifndef STUDENT_H
#define STUDENT_H

#include <string>

class Student {
private:
    std::string name;
    int birthYear;
    std::string major;
    std::string id;
    float gpa;

public:
    Student(std::string n, int bYear, std::string m, std::string i, float g);
    
    // Getters
    std::string getId() const;
    std::string getName() const;
    int getBirthYear() const;
    std::string getMajor() const;
    float getGpa() const;

    // Setters
    void setName(const std::string& n);
    void setBirthYear(int bYear);
    void setMajor(const std::string& m);
    void setGpa(float g);

    // Display and File I/O helpers
    void display() const;
    std::string toFileString() const;
};

#endif