#ifndef MANAGEMENT_H
#define MANAGEMENT_H

#include "student.h"
#include <vector>
#include <string>

class Management {
private:
    std::vector<Student> students;
    const std::string filename = "student_data.txt";
    
    // Validation helpers
    bool isValidName(const std::string& name);
    bool isValidBirthYear(int year);
    bool isValidId(const std::string& id);
    bool isValidGPA(const std::string& gpaStr, float& gpaOut);

    // Input helpers to reuse validation logic for both Add and Edit
    std::string inputName();
    int inputBirthYear();
    std::string inputMajor();
    std::string inputId();
    float inputGPA();

public:
    Management(); // Constructor to automatically load data on startup
    ~Management(); // Destructor to automatically save data on exit

    void addStudent();
    void editStudent();
    void deleteStudent();
    void displayStudent() const;
    void saveToFile() const;
    void loadFromFile();
    void run();
};

#endif